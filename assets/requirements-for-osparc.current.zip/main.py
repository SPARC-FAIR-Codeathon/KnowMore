# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 12:02:33 2021

@author: Bhavesh
"""

## import packages
import os
import pandas as pd

## define parameters depending on if you are running the code 
## on osparc or locally
if "INPUT_FOLDER" in os.environ:
    #In o²S²PARC, INPUT_FOLDER and OUTPUT_FOLDER are environment variables 
    #that map to the service input/output ports, respectively
    input_dir = os.environ["INPUT_FOLDER"] 
    output_dir = os.environ["OUTPUT_FOLDER"]
else:
    #local input/output folders
    current_folder = os.getcwd()
    input_dir = os.path.join(current_folder, "INPUT_FOLDER")
    output_dir = os.path.join(current_folder, "OUTPUT_FOLDER")


### main code  
# read input file
inputfile_xlsx_name = "input.xlsx"
input_xlsx = os.path.join(input_dir, inputfile_xlsx_name) 
#df_input = pd.read_excel(input_xlsx, index_col=0) 
#
#  
## write excel 
#df_output = df_input
#df_output['Name'] = ["Name A", "Name B", "Name C"]
#outputfile_xlsx_name = "output.xlsx"
#output_xlsx = os.path.join(output_dir, outputfile_xlsx_name) 
#df_output.to_excel(output_xlsx) 

# write text 
text = "Hello world!" + str(input_xlsx)
outputfile_txt_name = "my_output_file.txt" 
outputfile_txt= os.path.join(output_dir, outputfile_txt_name) 
f = open(outputfile_txt, "w")
f.write(text)
f.close()

